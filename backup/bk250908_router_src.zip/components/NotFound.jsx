function NotFound() {
  return (
    <>
      <h2 style={{color: 'red'}}>낫 파운드</h2>
    </>
  )
}

export default NotFound